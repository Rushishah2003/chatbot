<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:100,200,300,400,500,600,700,800,900" rel="stylesheet">

    <title>ZoZo the Career Buddy</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-eduwell-style.css" />
    <link rel="stylesheet" href="assets/css/owl.css">
    <link rel="stylesheet" href="assets/css/lightbox.css">
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

    <?php
session_start();
if(!isset($_SESSION["username"])){
header("Location: login.php");
exit(); }
else{
    ?>
    <header class="header-area header-sticky">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <nav class="main-nav">
                    <a href="index.html" class="logo">
                        <img src="assets/images/LOGO-re.png" alt="EduWell Template">
                    </a>
                    <ul class="nav">
                        <li class="scroll-to-section"><a href="#top" class="active">Home</a></li>
                        <li class="scroll-to-section"><a href="#services">Technologies Used</a></li>
                        <li class="scroll-to-section"><a href="#testimonials">Blog</a></li>
                        <li class="scroll-to-section"><a href="#contact-section">Contact Us</a></li>
                        <li><a href="about-us.html">About Us</a></li>
                        <li class="username"></li>
                    </ul>
                    <a class='menu-trigger'>
                        <span>Menu</span>
                    </a>
                </nav>
            </div>
        </div>
    </div>
</header>
<!-- ***** Header Area End ***** -->

<!-- ***** Main Banner Area Start ***** -->
<section class="main-banner-2" id="top">
    <div class="container">
        <div class="head-text">
            <h2>Hi, I am ZoZo</h2>
        </div>
        <div class="cent-image">
            <img src="assets/images/chatbot.png" alt="">
        </div>
        <div class="row">
            <div class="col-lg-6 align-self-center">
                <div class="header-text">
                    <div class="main-button-gradient">
                        <button> <a href=" http://127.0.0.1:5000", target="_blank">counselling Chat Bot</a></button>
                    </div>
                    <div class="h-text">
                        <p>
                            Let ZoZo choose the most suitable career according <br> to your interest
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 align-self-center">
                <div class="header-text">

                <div class="chatbox">
                    <div class="chatbox__support">
                        <div class="chatbox__header">
                            <div class="chatbox__image--header">
                                <img src="assets/images/chatbot.png" height="80px" alt="image">
                            </div>
                            <div class="chatbox__content--header">
                                <h3 class="chatbox__heading--header">Find here What you have to do?</h3>
                            </div>
                        </div>
                        <div class="chatbox__messages">
                            <div></div>
                        </div>
                        <div class="chatbox__footer">
                            <input type="text" placeholder="Write a message...">
                            <button class="chatbox__send--footer send__button">Send</button>
                        </div>
                    </div>
                    
                </div>


                <div class="chatbox__button">
                        <button>
                            Informative bot
                            
                        </button>
                    </div>
                    <!-- <div class="main-button-gradient chatbox-btn">
                        <button> <a href="login.php", target="_blank">Rishab Chat Bot</a></button>
                    </div> -->
                    <div class="h-text">
                        <p>Know More about specific career fields <br> and their eligibility criteria</p>
                    </div>
                </div>
            </div>
            <!-- <div class="col-lg-6">
                <div class="right-image">
                    <img src="assets/images/chatbot.png" alt="">
                </div>
            </div> -->
        </div>
    </div>
</section>
<!-- chat bot section need to be sticked on bottom right of the screen -->
<div class="container">
        
    </div>

    <script type="text/javascript" src="assets/js/app.js"></script>
<?php } ?>

    
   
    

    <!-- <div class="header-text">
                        <h6>Discover your Ideal Career</h6>
                        <hr>
                        <h2>Get the best career guidance , <em>counselling to discover yourself and your ideal career.</em></h2>
                        <div class="main-button-gradient">
                            <div class="scroll-to-section">
                                
                            </div>
                            <div>
                                <button> <a href="login.php", target="_blank">Get Councilled</a></button>
                            </div>
                            <div>
                                <button> <a href="login.php", target="_blank">Decide your path</a></button>
                            </div>
                        </div>
                    </div> -->
