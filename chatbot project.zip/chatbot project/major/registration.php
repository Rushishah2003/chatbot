<!DOCTYPE html>
<html>
<meta charset="utf-8">
<head>
<title>Registration</title>
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="assets\css\login-css for only login pages" />
<link rel="stylesheet" href="assets/css/templatemo-eduwell-style.css" />
<link rel="stylesheet" href="assets/css/style.css">

</head>
<body>
<?php
require('db.php');
// If form submitted, insert values into the database.
if (isset($_REQUEST['username'])){
        // removes backslashes
	$username = stripslashes($_REQUEST['username']);
        //escapes special characters in a string
	$username = mysqli_real_escape_string($con,$username); 
	$email = stripslashes($_REQUEST['email']);
	$email = mysqli_real_escape_string($con,$email);
	$password = stripslashes($_REQUEST['password']);
	$password = mysqli_real_escape_string($con,$password);

  $age = stripslashes($_REQUEST['age']);
	$age = mysqli_real_escape_string($con,$age);
  $gender = stripslashes($_REQUEST['gender']);
	$gender = mysqli_real_escape_string($con,$gender);
  $location = stripslashes($_REQUEST['location']);
	$location = mysqli_real_escape_string($con,$location);

	$trn_date = date("Y-m-d H:i:s");
        $query = "INSERT into `users` (username, password, email, trn_date, age, gender, location)
VALUES ('$username', '".md5($password)."', '$email', '$trn_date', '$age', '$gender', '$location')";
        $result = mysqli_query($con,$query);
        if($result){
            echo "<div class='form'>
<h3>You are registered successfully.</h3>
<br/>Click here to <a href='login.php'>Login</a></div>";
        }
    }else{
?>

<div class="form">
<h1>Registration</h1>
    <form name="registration" class="form-bot" action="" method="post">
              <div class="section-heading">
                <h5>Hello!!<em>Register For Your Career Guidance Tour</em></h5>
              </div>
                <input type="text" class="ip" name="username" placeholder="Username" required />
                <input type="number" class="ip" name="age" placeholder="Age" min="16" max="75" required />
                <p><input type="radio" class="ip" name="gender" value="male">Male 
                <input type="radio" class="ip" name="gender" value="female">Female
                <input type="radio" class="ip" name="gender" value="other">Others
              </p>
                <input type="text" class="ip" name="location" placeholder="Location" required />
                <input type="email" name="email" class="ip" id="email" placeholder="Your Email" required="">
                <input type="password" name="password" class="ip" placeholder="Password" required />
                <input type="submit" class="submit" name="submit" value="Register" /> 
      </form>

<!--<input type="text" name="username" placeholder="Username" required />
<input type="email" name="email" placeholder="Email" required />
<input type="password" name="password" placeholder="Password" required />
<input type="submit" name="submit" value="Register" />
</form>-->
</div>
<?php } ?>
<!--<div class="col-lg-4">
          <form id="contact" action="mail.php" method="post">
            <div class="row">
              <div class="col-lg-12">
                <div class="section-heading">
                  <h6>Contact us</h6>
                  <h4>Say <em>Hello</em></h4>
                  <p>IF you wish to ask any quary form developer's team feel free - </p>
                </div>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <input type="name" name="name" id="name" placeholder="Full Name" autocomplete="on" required>
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <input type="text" name="email" id="email" pattern="[^ @]*@[^ @]*" placeholder="Your Email" required="">
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <textarea name="message" id="message" placeholder="Your Message"></textarea>
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <button type="submit" id="form-submit" class="main-gradient-button">Send Message</button>
                </fieldset>
              </div>
            </div>
          </form>
        </div>-->
</body>
</html>
